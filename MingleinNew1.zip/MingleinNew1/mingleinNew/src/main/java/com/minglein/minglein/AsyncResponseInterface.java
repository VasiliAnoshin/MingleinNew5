package com.minglein.minglein;

public interface AsyncResponseInterface {
	void onFinishGetInfo(String output);
	void onFinishPostInfo(String matches);
}
