/** Automatically generated file. DO NOT MODIFY */
package com.linkedin.android.mobilesdk;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}